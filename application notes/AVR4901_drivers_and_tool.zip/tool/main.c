#include <stdio.h>
#include <time.h>
#include "usb.h"

/**
 * Device vendor definition
 */
//@{

#define DEVICE_VENDOR_VID 0x03eb
#define DEVICE_VENDOR_PID 0x2423

// the device's endpoints
static unsigned char udi_vendor_ep_interrupt_in ;
static unsigned char udi_vendor_ep_interrupt_out;
static unsigned char udi_vendor_ep_bulk_in      ;
static unsigned char udi_vendor_ep_bulk_out     ;
static unsigned char udi_vendor_ep_iso_in       ;
static unsigned char udi_vendor_ep_iso_out      ;

static unsigned short udi_vendor_ep_iso_size;

//! Size of buffer used for the loopback
#define  UDI_VENDOR_LOOPBACK_SIZE    1024

uint8_t udi_vendor_buf_out[UDI_VENDOR_LOOPBACK_SIZE];
uint8_t udi_vendor_buf_in[UDI_VENDOR_LOOPBACK_SIZE];

//@}

static void init_buffers(void);
static int cmp_buffers(void);
static int loop_back_control(usb_dev_handle *device_handle);
static int loop_back_interrupt(usb_dev_handle *device_handle);
static int loop_back_bulk(usb_dev_handle *device_handle);
static int loop_back_isochronous(usb_dev_handle *device_handle, struct usb_device *device);

/// The main entry-point function.
int main (int argc, char *argv[])
{
	struct usb_bus *bus;
	struct usb_device *device;
	usb_dev_handle *device_handle = NULL; // the device handle
	char string_usb[100];


	printf("-------------\n");
	printf("------ PC tool for ASF vendor class example (V1.3)\n");

	// Libusb initialization
	printf("Initialization library \"libusb\"...\n");
	usb_init();         // initialize the library
	usb_find_busses();  // find all busses
	usb_find_devices(); // find all connected devices

	// Search and open device
	printf("Search device...\n");
	for(bus = usb_get_busses(); bus; bus = bus->next) {
		for(device = bus->devices; device; device = device->next) {
			if(device->descriptor.idVendor == DEVICE_VENDOR_VID 
					&& device->descriptor.idProduct == DEVICE_VENDOR_PID) {
				device_handle = usb_open(device);
				break;
			}
		}
	}
	if(device_handle == NULL) {
		printf("error: device not found!\n");
		return 0;
	}
	printf("USB Device of ASF vendor class example found:\n");
	printf("- Device version: %d.%d\n", device->descriptor.bcdDevice>>8, (device->descriptor.bcdDevice&0xFF));
	if (0!=device->descriptor.iManufacturer) {
		usb_get_string_simple(device_handle, device->descriptor.iManufacturer, string_usb, sizeof(string_usb));
		printf("- Manufacturename: %s\n",string_usb);
	}
	if (0!=device->descriptor.iProduct) {
		usb_get_string_simple(device_handle, device->descriptor.iProduct, string_usb, sizeof(string_usb));
		printf("- Product name: %s\n",string_usb);
	}
	if (0!=device->descriptor.iSerialNumber) {
		usb_get_string_simple(device_handle, device->descriptor.iSerialNumber, string_usb, sizeof(string_usb));
		printf("- Serial number: %s\n\n",string_usb);
	}

	printf("- Endpoint list:\n");
	udi_vendor_ep_interrupt_in = 0;
	udi_vendor_ep_interrupt_out= 0;
	udi_vendor_ep_bulk_in      = 0;
	udi_vendor_ep_bulk_out     = 0;
	udi_vendor_ep_iso_in       = 0;
	udi_vendor_ep_iso_out      = 0;

	unsigned char nb_ep = 0;
	struct usb_endpoint_descriptor *endpoints;
	if (1==device->config->interface->num_altsetting) {
		// Old firmwares have no alternate setting
		nb_ep = device->config->interface->altsetting[0].bNumEndpoints;
		endpoints = device->config->interface->altsetting[0].endpoint;
	} else {
		// The alternate setting has been added to be USB compliance:
		// 1.2.40 An Isochronous endpoint present in alternate interface 0x00 must have a MaxPacketSize of 0x00
		// Reference document: Universal Serial Bus Specification, Revision 2.0, Section 5.6.3.
		nb_ep = device->config->interface->altsetting[1].bNumEndpoints;
		endpoints = device->config->interface->altsetting[1].endpoint;
	}
	while (nb_ep) {
		nb_ep--;

		unsigned char ep_type = endpoints[nb_ep].bmAttributes
				& USB_ENDPOINT_TYPE_MASK;
		unsigned char ep_add = endpoints[nb_ep].bEndpointAddress;
		unsigned char dir_in = (ep_add & USB_ENDPOINT_DIR_MASK) == USB_ENDPOINT_IN;
		unsigned short ep_size = endpoints[nb_ep].wMaxPacketSize;

		switch (ep_type) {
			case USB_ENDPOINT_TYPE_INTERRUPT:
				if (dir_in) {
					udi_vendor_ep_interrupt_in = ep_add;
				} else {
					udi_vendor_ep_interrupt_out= ep_add;
				}
				break;
			case USB_ENDPOINT_TYPE_BULK:
				if (dir_in) {
					udi_vendor_ep_bulk_in = ep_add;
				} else {
					udi_vendor_ep_bulk_out= ep_add;
				}
				break;
			case USB_ENDPOINT_TYPE_ISOCHRONOUS:
				udi_vendor_ep_iso_size = ep_size;
				if (dir_in) {
					udi_vendor_ep_iso_in = ep_add;
				} else {
					udi_vendor_ep_iso_out= ep_add;
				}
				break;
		}
	}
	if (udi_vendor_ep_interrupt_in)
		printf("  - Endpoint interrupt IN:  %02X\n", udi_vendor_ep_interrupt_in );
	if (udi_vendor_ep_interrupt_out)
		printf("  - Endpoint interrupt OUT: %02X\n", udi_vendor_ep_interrupt_out);
	if (udi_vendor_ep_bulk_in)
		printf("  - Endpoint bulk      IN:  %02X\n", udi_vendor_ep_bulk_in );
	if (udi_vendor_ep_bulk_out)
		printf("  - Endpoint bulk      OUT: %02X\n", udi_vendor_ep_bulk_out);
	if (udi_vendor_ep_iso_in)
		printf("  - Endpoint iso       IN:  %02X\n", udi_vendor_ep_iso_in );
	if (udi_vendor_ep_iso_out)
		printf("  - Endpoint iso       OUT: %02X\n", udi_vendor_ep_iso_out);

	// Open interface vendor
	printf("Initialization device...\n");
	if(usb_set_configuration(device_handle, 1) < 0) {
		printf("error: setting config 1 failed\n");
		usb_close(device_handle);
		return 0;
	}
	if(usb_claim_interface(device_handle, 0) < 0) {
		printf("error: claiming interface 0 failed\n");
		usb_close(device_handle);
		return 0;
	}
	if (1!=device->config->interface->num_altsetting) {

		if(usb_set_altinterface(device_handle, 1) < 0) {
			printf("error: set alternate 1 interface 0 failed\n");
			usb_close(device_handle);
			return 0;
		}
	}
	// LoopS back
	printf("Control enpoint loop back...\n");
	init_buffers();
	if (loop_back_control(device_handle)) {
		printf("Error during control endpoint transfer\n");
		usb_close(device_handle);
		return 0;
	}
	if (cmp_buffers()) {
		usb_close(device_handle);
		return 0;
	}

	if (udi_vendor_ep_interrupt_in && udi_vendor_ep_interrupt_out) {
		printf("Interrupt enpoint loop back...\n");
		init_buffers();
		if (loop_back_interrupt(device_handle)) {
			printf("Error during interrupt endpoint transfer\n");
			usb_close(device_handle);
			return 0;
		}
		if (cmp_buffers()) {
			usb_close(device_handle);
			return 0;
		}
	}
	
	if (udi_vendor_ep_bulk_in && udi_vendor_ep_bulk_out) {
		printf("Bulk enpoint loop back...\n");
		init_buffers();
		if (loop_back_bulk(device_handle)) {
			printf("Error during bulk endpoint transfer\n");
			usb_close(device_handle);
			return 0;
		}
		if (cmp_buffers()) {
			usb_close(device_handle);
			return 0;
		}
	}
		
	if (udi_vendor_ep_iso_in && udi_vendor_ep_iso_out) {
		printf("Isochronous enpoint loop back...\n");
		if (loop_back_isochronous(device_handle, device)) {
			printf("Error during isochronous endpoint transfer\n");
			usb_close(device_handle);
			return 0;
		}
	}

	usb_close(device_handle);
	printf("------ Tests completed.\n");
	printf("-------------\n");
	return 1;
}

static void init_buffers(void)
{
	int i;
	// Fill buffer OUT
	for (i=0; i<sizeof(udi_vendor_buf_out); i+=4 ) {
		udi_vendor_buf_out[i+0] = (i>>24)&0xFF;
		udi_vendor_buf_out[i+1] = (i>>16)&0xFF;
		udi_vendor_buf_out[i+2] = (i>> 8)&0xFF;
		udi_vendor_buf_out[i+3] = (i>> 0)&0xFF;
	}
	// Reset buffer IN
	memset(udi_vendor_buf_in,0x55,sizeof(udi_vendor_buf_in));
}

static int cmp_buffers(void)
{
	if (0!=memcmp( udi_vendor_buf_out, udi_vendor_buf_in, sizeof(udi_vendor_buf_in)) ) {
		printf("!Wrong data! Error in loopback\n");
		return -1;
	}
	return 0;
}

static int loop_back_control(usb_dev_handle *device_handle)
{

	if (0 > usb_control_msg(
			device_handle,
			USB_TYPE_VENDOR | USB_RECIP_INTERFACE , // bRequestType
			0, // bRequestm
			0, // wValue
			0, // wIndex
			udi_vendor_buf_out, // pointer to destination buffer
			sizeof(udi_vendor_buf_out), // wLength
			1000 // timeout ms
			)) {
		return -1;
	}

	if (0 > usb_control_msg(
			device_handle,
			USB_TYPE_VENDOR | USB_RECIP_INTERFACE | USB_ENDPOINT_IN, // bRequestType
			0, // bRequest
			0, // wValue
			0, // wIndex
			udi_vendor_buf_in, // pointer to destination buffer
			sizeof(udi_vendor_buf_in), // wLength
			1000 // timeout ms
			)) {
		return -1;
	}

	return 0;
}

static int loop_back_interrupt(usb_dev_handle *device_handle)
{
	if (0> usb_interrupt_write( device_handle,
			udi_vendor_ep_interrupt_out,
			udi_vendor_buf_out,
			sizeof(udi_vendor_buf_out),
			1000)) {
		return -1;
	}
	if (0> usb_interrupt_read( device_handle,
			udi_vendor_ep_interrupt_in,
			udi_vendor_buf_in,
			sizeof(udi_vendor_buf_in),
			1000)) {
		return -1;
	}
	return 0;
}

static int loop_back_bulk(usb_dev_handle *device_handle)
{
	if (0> usb_bulk_write( device_handle,
			udi_vendor_ep_bulk_out,
			udi_vendor_buf_out,
			sizeof(udi_vendor_buf_out),
			1000)) {
		return -1;
	}
	if (0> usb_bulk_read( device_handle,
			udi_vendor_ep_bulk_in,
			udi_vendor_buf_in,
			sizeof(udi_vendor_buf_in),
			1000)) {
		return -1;
	}
	return 0;
}

static int loop_back_isochronous(usb_dev_handle *device_handle, struct usb_device *device)
{
#define ISO_NB_TRANS 2048
	uint8_t udi_vendor_buf_isochronous_out[ISO_NB_TRANS];
	uint8_t udi_vendor_buf_isochronous_in[5*ISO_NB_TRANS];
	void *context_in = NULL;
	void *context_out = NULL;
	int i,j, size_ep;

	size_ep = min(ISO_NB_TRANS, udi_vendor_ep_iso_size);

	// Fill buffer OUT
	for (i=0; i<sizeof(udi_vendor_buf_isochronous_out); i+=4 ) {
		udi_vendor_buf_isochronous_out[i+0] = 'S';
		udi_vendor_buf_isochronous_out[i+1] = (i>>16)&0xFF;
		udi_vendor_buf_isochronous_out[i+2] = (i>> 8)&0xFF;
		udi_vendor_buf_isochronous_out[i+3] = (i>> 0)&0xFF;
	}

	// Init buffer reception (To patch libusb behavior which add padding in buffer)
	memset(udi_vendor_buf_isochronous_in, 0xFF, sizeof(udi_vendor_buf_isochronous_in));

	if (0!=usb_isochronous_setup_async(device_handle, &context_out, udi_vendor_ep_iso_out,size_ep/2)) {
		return -1;
	}
	if (0!=usb_isochronous_setup_async(device_handle, &context_in, udi_vendor_ep_iso_in,size_ep)) {
		return -1;
	}

	// Sent on OUT
	if (0!=usb_submit_async(context_out, udi_vendor_buf_isochronous_out, sizeof(udi_vendor_buf_isochronous_out))) {
		return -1;
	}

	// Receiv on IN
	if (0!=usb_submit_async(context_in, udi_vendor_buf_isochronous_in, sizeof(udi_vendor_buf_isochronous_in))) {
		return -1;
	}

	if (0>usb_reap_async(context_out, 20000)) {
		return -1;
	}
	if (0>usb_reap_async(context_in, 20000)) {
		return -1;
	}
	
	if (0!=usb_free_async(&context_out)) {
		return -1;
	}
	if (0!=usb_free_async(&context_in)) {
		return -1;
	}

	// Impossible to compare, libusb must include a bug
	// because a padding at 0x00 is added sometime.
	/*

	// Concatenate buffer data = remove 0xFF data
	// To patch libusb behavior which add padding in buffer
	i=0; // dest
	j=0; // source
	while ((i<sizeof(udi_vendor_buf_isochronous_out))&&(j<sizeof(udi_vendor_buf_isochronous_in))) {
		if (udi_vendor_buf_isochronous_in[j]!=0xFF) {
			udi_vendor_buf_isochronous_in[i++] = udi_vendor_buf_isochronous_in[j];
		}
		j++;
	}
	while ((i<sizeof(udi_vendor_buf_isochronous_out))&&(j<sizeof(udi_vendor_buf_isochronous_in))) {
		if (udi_vendor_buf_isochronous_in[j]!=0xFF) {
			udi_vendor_buf_isochronous_in[i++] = udi_vendor_buf_isochronous_in[j];
		}
		j++;
	}

	if (0!=memcmp( udi_vendor_buf_isochronous_out,
			udi_vendor_buf_isochronous_in,
			sizeof(udi_vendor_buf_isochronous_out)) ) {
			printf("Error compare buffer\n");
		return -1;
	}

	*/
	return 0;
}


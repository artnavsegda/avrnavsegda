#include <avr/io.h>
#include <util/delay.h>

#define TWI_BAUD(F_SYS, F_TWI) ((F_SYS / (2 * F_TWI)) - 5)

int main(void)
{
	//twi init
	TWIC.MASTER.CTRLA = TWI_MASTER_INTLVL_LO_gc | TWI_MASTER_RIEN_bm | TWI_MASTER_WIEN_bm | TWI_MASTER_ENABLE_bm;
	TWIC.MASTER.BAUD = TWI_BAUD(2000000, 100000);
	TWIC.MASTER.STATUS = TWI_MASTER_BUSSTATE_IDLE_gc;
	while (1)
	{
		//twi address
		TWIC.MASTER.ADDR = 0x20;
		loop_until_bit_is_set(TWIC.MASTER.STATUS, TWI_MASTER_WIF_bp);
		//twi data
		TWIC.MASTER.ADDR = 0x34;
		loop_until_bit_is_set(TWIC.MASTER.STATUS, TWI_MASTER_WIF_bp);
		//twi stop
		TWIC.MASTER.CTRLC = TWI_MASTER_CMD_STOP_gc;
		_delay_ms(1000);
	}
	return 0;
}

